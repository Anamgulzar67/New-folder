import React from 'react'

const Header = () => {
  return (
    <div className='border'>
      <h2>Expense tracker</h2>
    </div>
  )
}

export default Header
